package hello;

public class HelloGoodbye {
    public static void main(String[] args) { 

        System.out.println("Hello\s"+ args[0]+"\sand\s"+ args[1]);
        System.out.println("Goodbye\s"+ args[0]+"\sand\s"+ args[1]);

    }
}
